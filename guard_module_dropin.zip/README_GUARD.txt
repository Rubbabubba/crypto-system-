Drop-in fix for 'ModuleNotFoundError: guard'

Files included:
- guard.py  -> Place next to your existing app.py on Render (same directory).
               It reads policy files from POLICY_CFG_DIR (defaults to ./policy_config).

No route changes required. Your current app.py imports:
    from guard import load_policy, guard_allows
and will start successfully after this file is added.

Notes:
- whitelist.json and windows.json should live in: ./policy_config (or set env POLICY_CFG_DIR).
- If those files are missing/empty, guard_allows() defaults to allow-all and returns reason 'no_policy'.
